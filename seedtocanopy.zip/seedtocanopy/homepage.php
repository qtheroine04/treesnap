<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link rel="stylesheet" href="homepage.css">
</head>
<body>
    <div class="hero">

        <video autoplay loop muted plays-inline class="back-video">
            <source src="img/bg.mp4" type="video/mp4">
        </video>

        <nav>
            <img src="img/tree.png" class="logo">
           
        </nav>
        <div class="content">
            <h1>Seed To Canopy</h1>
            <?php
           
            session_start();
            if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
                echo '<a href="user/logout.php">Logout</a>';
            } else {
                echo '<a href="user/login.php">Get Started</a>';
            }
            ?>
        </div>
    </div>
</body>
</html>
