<?php
session_start();


if (!isset($_SESSION['username'])) {
    
    header("Location: ../homepage.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
    <style>
      
    </style>
</head>
<body>
    <div class="hero">
        <video autoplay loop muted playsinline class="back-video">
            <source src="img/bg.mp4" type="video/mp4">
        </video>
        <nav>
            <img src="img/tree.png" class="logo" alt="Logo">
        </nav>
        <div class="content">
            <h1>Seed To Canopy</h1>
            <a onclick="confirmLogout()">Logout</a>
        </div>
    </div>
   
    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to log out?")) {
                window.location.href = 'logout.php';
            }
        }
    </script>
</body>
</html>
