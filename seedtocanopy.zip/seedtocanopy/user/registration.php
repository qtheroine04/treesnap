<?php
session_start();

include("../include/connection.php");

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $fullname = $_POST['full_name']; 
    $contactnumber = $_POST['contact_number']; 
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repeatPassword = $_POST['repeat_password'];

    if ($password !== $repeatPassword) {
        $error = "Password and Confirm Password must match.";
    } else {
        $sql = "INSERT INTO usertb (fullname, username, email, contact_number, password)
                VALUES (:fullname, :username, :email, :contactnumber, :password)";

        try {
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':fullname', $fullname);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':contactnumber', $contactnumber);
            $stmt->bindParam(':password', $password); 
            $stmt->execute();

            header('Location: login.php'); 
            exit();
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="registration.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="hero">
        <video autoplay loop muted plays-inline class="back-video">
            <source src="img/bg.mp4" type="video/mp4">
        </video>

        <nav>
            <img src="img/tree.png" class="logo">
            <ul>
                <li><a href="homepage.html">HOME</a></li>
                <li><a href="about.html">ABOUT</a></li>
            </ul>
        </nav>

        <div class="wrapper">
            <form name="user/registration" method="POST" action="">
                <h1>SignUp</h1>
                <?php
                if (isset($error)) {
                    echo '<p>' . $error . '</p>';
                }
                ?>
                <div class="input-box">
                    <div class="input-field">
                        <input type="text" placeholder="Full Name" name="full_name" required>
                        <i class='bx bxs-user'></i>
                    </div>
                    <div class="input-field">
                        <input type="text" placeholder="Username" name="username" required>
                        <i class='bx bxs-user'></i>
                    </div>
                </div>
                <div class="input-box">
                    <div class="input-field">
                        <input type="email" placeholder="Email" name="email" required>
                        <i class='bx bxs-envelope'></i>
                    </div>
                    <div class="input-field">
                        <input type="number" placeholder="Contact Number" name="contact_number" required>
                        <i class='bx bxs-phone'></i>
                    </div>
                </div>
                <div class="input-box">
                    <div class="input-field">
                        <input type="password" placeholder="Password" name="password" required>
                        <i class='bx bxs-lock-alt'></i>
                    </div>
                    <div class="input-field">
                        <input type="password" placeholder="Confirm Password" name="repeat_password" required>
                        <i class='bx bxs-lock-alt'></i>
                    </div>
                </div>
                <button type="submit" class="button" name="submit">Register</button>
            </form>
        </div>
    </div>
</body>
</html>
