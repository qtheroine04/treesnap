<?php
try {
    $servername = "localhost";
    $database = "seedtocanopy";
    $username = "root";
    $password = "";

    $pdo = new PDO ("mysql:host=$servername:3306;dbname=$database",$username,$password);


    $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

    
} catch (PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();
}
?>